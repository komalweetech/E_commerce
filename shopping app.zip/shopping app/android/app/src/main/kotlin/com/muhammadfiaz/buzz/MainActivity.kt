package com.muhammadfiaz.buzz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
