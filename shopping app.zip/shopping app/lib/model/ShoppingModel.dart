class ShoppingModel {
  String? name;
  String? subtitle;
  String? img;
  String? amount;

  ShoppingModel({this.name, this.img, this.subtitle, this.amount});
}
