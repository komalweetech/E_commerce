const isDarkModeOnPref = 'isDarkModeOnPref';

const appName = "Buzz Shopping";
